import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forgot-email',
  templateUrl: './forgot-email.component.html',
  styleUrls: ['./forgot-email.component.scss']
})
export class ForgotEmailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
